import React from 'react';
import { Switch } from 'react-router-dom';
import Header from './Components/Header/Header';




const App = () => {
  
  return (
    <div>
      <Header />

      {/* <Switch>

      </Switch> */}

      {/* <Footer /> */}
    </div>
  );
};

export default App;